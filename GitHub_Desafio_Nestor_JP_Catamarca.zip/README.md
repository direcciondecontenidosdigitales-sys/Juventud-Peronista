# Desafío Néstor — JP Catamarca

Juego interactivo de tres preguntas sobre políticas públicas impulsadas durante el gobierno de Néstor Kirchner (2003–2007).

- Portada tipográfica sin foto de Néstor.
- Tres desafíos: salario mínimo, moratoria previsional y Plan Nacer.
- Dos opciones por pregunta, con orden variable.
- Respuesta correcta con explicación histórica; ante un error también aparece una clave política contextual.
- Puntaje final, opción para volver a jugar y compartir.

## Publicarlo en GitHub Pages

1. En tu cuenta de GitHub, creá un repositorio **público** llamado `Desafio-Nestor-JP-Catamarca` (o elegí otro nombre).
2. En el repositorio, seleccioná **Add file → Upload files**. Subí **los archivos descomprimidos de este ZIP** al inicio del repositorio (no el ZIP sin extraer) y confirmá con **Commit changes**.
3. Entrá a **Settings → Pages**. En **Build and deployment**, elegí **Deploy from a branch**, rama `main`, carpeta `/(root)` y guardá.
4. Esperá a que GitHub confirme la publicación. La dirección esperada, si usás el nombre indicado, será:

   `https://direcciondecontenidosdigitales-sys.github.io/Desafio-Nestor-JP-Catamarca/`

**Importante:** la dirección no funciona hasta que el repositorio exista y Pages termine de publicar. No reemplaces los archivos de otro proyecto.

## Archivos

- `index.html`: sitio completo, accesible desde celulares, sin dependencias de compilación.
- `logo-jp.jpg`: logo que aparece en la cabecera.

El juego no requiere servidor, base de datos ni contraseñas y no recopila las respuestas de los visitantes.

## Fuentes históricas

- [Salario mínimo: Decreto 1349/2003](https://www.argentina.gob.ar/normativa/nacional/decreto-1349-2003-91518/texto)
- [Moratoria previsional: Ley 25.994](https://www.argentina.gob.ar/normativa/nacional/ley-25994-102726/texto)
- [Plan Nacer: Resolución 1173/2004](https://www.argentina.gob.ar/normativa/nacional/resoluci%C3%B3n-1173-2004-100611/texto)
